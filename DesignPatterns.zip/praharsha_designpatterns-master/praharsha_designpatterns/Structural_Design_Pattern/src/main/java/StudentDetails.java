
public interface StudentDetails {
public void show(String fname,String lname,int id);
}
