
public class civil implements Branch {
public void count()
{
	System.out.println("950");
}
}
