
public class mec implements Branch {

	public void count()
	{
		System.out.println("1000");
	}
}
