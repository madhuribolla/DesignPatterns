
public class Facadedesignpattern {
public static void main(String args[])
{
	activityfactory b=new activityfactory();
	b.csecount();
	b.ececount();
	b.meccount();
	b.civilcount();
	
	
	
	
	
}
}
