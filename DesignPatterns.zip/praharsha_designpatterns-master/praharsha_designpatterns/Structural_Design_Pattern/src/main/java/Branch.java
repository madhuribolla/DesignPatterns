
public interface Branch {
public void count();

}
