
public interface fileaccess {
public void share();

}
