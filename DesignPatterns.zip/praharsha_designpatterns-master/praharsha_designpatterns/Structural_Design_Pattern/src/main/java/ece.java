
public class ece implements Branch{
public void count()
{
	System.out.println("1220");
	
}
}
