
public class cse implements Branch {
	public void count()
	{
		System.out.println("1000");
	}

}
