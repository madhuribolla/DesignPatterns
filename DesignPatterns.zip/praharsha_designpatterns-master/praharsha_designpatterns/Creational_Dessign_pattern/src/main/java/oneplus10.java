
public class oneplus10 implements Specialization{
	public void camera()
	{
		System.out.println("Rear Camera Megapixel:12+12+12");
		System.out.println("Front Camera Megapixel");
		
	}
	public void storagecapacity()
	{
		
		System.out.println("128GB");
	}
	public void cost()
	{
		System.out.println("75000");
	}

}
