
public class oneplus9 implements Specialization {
	public void camera()
	{
		System.out.println(" 28mm 12-megapixel camera with optical image stabilization, a wider f/1.8 aperture 6-element lens, wide color capture");
	}
public void storagecapacity()
{
	System.out.println("Storage Capacity of 64GB internal");
	
}public void cost()
{
	System.out.println("35000");
}

}
