
public class oneplus8 implements Specialization {
	
	
	public void camera()
	{
		System.out.println("Real Auto Focus");
		
		System.out.println("flash");
		
	}
		public void storagecapacity()
	{
		System.out.println("32GB internal");
		
		
	}
		public void cost()
		{
			System.out.println("28000");
		}

}
