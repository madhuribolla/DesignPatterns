
public interface Specialization {
	public void camera();
	public void storagecapacity();
	public void cost();

}
