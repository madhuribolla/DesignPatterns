
public class Subtraction implements Calculator {
	public void Calculation(int a,int b)
	{
		System.out.println(a-b);
		
	}

}
