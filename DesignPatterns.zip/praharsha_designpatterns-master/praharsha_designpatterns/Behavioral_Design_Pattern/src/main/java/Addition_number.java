
public class Addition_number implements Calculator {

	public void Calculation(int a,int b)
	{
		System.out.println(a+b);
		
	}

}
