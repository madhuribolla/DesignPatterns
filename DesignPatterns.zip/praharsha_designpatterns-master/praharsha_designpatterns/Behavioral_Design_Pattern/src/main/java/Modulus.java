
public class Modulus_number  implements Calculator1 {

	public void Calculation(int a,int b)
	{
		System.out.println(a%b);
		
	}

}
