
public class Access {
public Calculator c;
Accessfactor(Calculator c)
{
	this.c=c;
	
}
public void accessing(int a,int b)
{
	c.Calculation(a,b);
	
}
}
