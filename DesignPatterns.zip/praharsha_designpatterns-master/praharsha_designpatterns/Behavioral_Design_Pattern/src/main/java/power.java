
public class power  implements Calculator{

	public void Calculation(int a,int b)
	{
		System.out.println(Math.pow(a, b));
		
	}
}
