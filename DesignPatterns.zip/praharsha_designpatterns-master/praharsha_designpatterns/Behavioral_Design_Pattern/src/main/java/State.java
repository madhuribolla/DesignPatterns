
public interface State {
public void action( A a);

}
