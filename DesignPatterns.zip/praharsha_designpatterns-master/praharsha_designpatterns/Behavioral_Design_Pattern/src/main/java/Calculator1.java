
public interface Calculator1{
public void Calculation(int a,int b);

}
