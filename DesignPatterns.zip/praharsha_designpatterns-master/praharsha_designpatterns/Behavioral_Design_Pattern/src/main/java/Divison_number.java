
public class Divison_number implements Calculator1{
	public void Calculation(int a,int b)
	{
		try
		{
int d=a/b;
		System.out.println(d);
		
	}
		catch(Exception e)
		{
			System.out.println(e);
		}

}
}
